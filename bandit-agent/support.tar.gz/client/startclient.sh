#!/bin/sh

numArms=$1
horizon=$2
hostname=$3
port=$4
randomSeed=$5

./bandit-agent/target/release/bandit-agent --arms $numArms --horizon $horizon --server $hostname:$port
