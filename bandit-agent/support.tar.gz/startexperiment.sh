#!/bin/bash

PWD=`pwd`

numArms=6
horizon=10000
port=5001
hostname="localhost"
banditFile="$PWD/data/instance-01.txt"
randomSeed=$RANDOM

echo "Seed: $randomSeed"

SERVERDIR=./server
CLIENTDIR=./client

OUTPUTFILE=$PWD/serverlog.txt

pushd $SERVERDIR > /dev/null
./startserver.sh $numArms $horizon $port $banditFile $randomSeed $OUTPUTFILE &
popd > /dev/null

sleep 0.4

pushd $CLIENTDIR > /dev/null
./startclient.sh $numArms $horizon $hostname $port $randomSeed
popd > /dev/null

tail -n 4 $OUTPUTFILE | sed -n "/Regret =/p"
